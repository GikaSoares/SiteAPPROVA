<?php 
session_start();
$_SESSION['teste']=6;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 7ºprova</h1>
		 
			<a href="../7/mes7.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>		  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteudo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
			
			
			
			
			<p></p>
			<p>1)Sobre a função poética da linguagem, é correto afirmar, exceto:</p>
			<p></p>
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) Está entre as seis funções da linguagem prescritas pelo linguista russo Roman Jakobson e, assim como as demais, está associada aos elementos da comunicação (emissor, receptor, mensagem, código, canal e contexto).</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B) A função poética coloca em evidência o lado palpável, material dos signos, conforme definição de Roman Jakobson. Isso significa dizer que a função poética está voltada para a própria mensagem.</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C)Nesse tipo de função, a mensagem está centrada no emissor, pois a intenção do produtor do texto é posicionar-se em relação ao tema abordado.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D)Na função poética predomina a linguagem metafórica, o que produz o efeito de subjetividade e lirismo aos textos em que essa função predomina..</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E)n.d.a</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<p> 2) Sobre a metalinguagem, podemos afirmar:</p>
				
					
				
				
				<p></p>
				
				
			<label>
				<input type="radio" name="questao2" value="a" /> A)Quando a preocupação do emissor está voltada para o próprio código, ou seja, para a própria linguagem, temos então o que chamamos de função metalinguística.</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B) A metalinguagem ocorre quando o emissor deseja verificar se o canal de comunicação está funcionando ou compreendendo a mensagem.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) Evidencia o assunto, o objeto, os fatos, os juízos. É a linguagem da comunicação..</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D) Quando há ênfase no emissor, ou seja, na primeira pessoa e na expressão direta de suas emoções e atitudes..</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)Busca mobilizar a atenção do receptor, produzindo um apelo ou uma ordem.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3)Nos trechos abaixo, de Dom Casmurro, de Machado de Assis, o narrador deixa de praticar a metalinguagem em:</p>
				<p></p>
				
				<p></p>
				
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A)  Agora que expliquei o título, passo a escrever o livro. Antes disso, porém, digamos os motivos que me põem a pena na mão.</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B)Tio Cosme vivia com minha mãe, desde que ela enviuvou. Já então era viúvo, como prima Justina; era a casa dos três viúvos. </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C) Releva-me estas metáforas; cheiram ao mar e à maré que deram morte ao meu amigo e comborço Escobar.</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D) D. Sancha, peço-lhe que não leia este livro; ou, se o houver lido até aqui, abandone o resto. .</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E)  Também não achei melhor título para a minha narração; se não tiver outro daqui até ao fim do livro, vai este mesmo.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4)"Assim eu quereria a minha última crônica: que fosse pura como este sorriso." (Fernando Sabino).</p>

 
			
			
			<br> </br>
			<p>Assinale a série em que estão devidamente classificadas as formas verbais em destaque:</p>
			
			<label>
				<input type="radio" name="questao4" value="a" /> A) futuro do pretérito, presente do subjuntivo.</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B)pretérito mais-que-perfeito, pretérito imperfeito do subjuntivo. </label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)pretérito mais-que-perfeito, presente do subjuntivo.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)futuro do pretérito, pretérito imperfeito do subjuntivo.</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)pretérito perfeito, futuro do pretérito.  </label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5)Sobre o modo subjuntivo, é correto afirmar:  </p>
			<p></p>
			
			<p>
			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A)Normalmente ocorre nas orações independentes optativas, nas imperativas negativas e afirmativas, nas dubitativas com o advérbio talvez e nas subordinadas em que o fato é considerado incerto, duvidoso ou pouco provável de se concretizar.</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  Normalmente aparece nas orações independentes e nas dependentes que sugerem um fato real, concretizado.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C)  Tempo de ações prolongadas ou repetidas com limites imprecisos, não informando assim nem o término e nem o início dessas. </label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D)Normalmente ocorre nas orações que expressam uma ordem, pedido ou conselho.</label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e) Normalmente é empregado nas ações que nos transportam mentalmente a uma época passada e nessa época passada descrevemos então o que era presente.</label>
				<br />
				<br />
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) lguns tempos do modo indicativo podem ser utilizados com valor imperativo. Está neste caso o verbo sublinhado na seguinte alternativa:


			

			<label>
				<input type="radio" name="questao6" value="a" /> A)  Faça logo esse serviço!</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)  Não matarás, diz a Bíblia...</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C)  Saiam logo depois do sinal.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) Prestem atenção ao que foi dito.

.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E)  Não desçam correndo a escada.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7)A frase em que há erro quanto ao emprego do pronome lhe é:</p>
				
			<p></p>
			<p></p>
			<p></p>
			
			<label>
				<input type="radio" name="questao7" value="a" /> A) Nunca lhe diria mentira..</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B) Ter-lhe-iam falado a meu respeito?.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)Louvemos-lhe, porque ele o merece.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)De Fernando só lhe conhecia a fama..</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E)Sei que não lhe agrada essa conversa..</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Marque a opção em que a forma pronominal utilizada está INCORRETA. </p>
				
			<p></p>
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)  É difícil, para mim, praticar certos exercícios físicos.</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) Ainda existem muitas coisas importantes para eu fazer.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)Os chinelos da aposentadoria não são para ti.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D) Quando a aposentadoria chegou, eu caí em si.</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E) Para tu não teres aborrecimentos, evita o excesso de velocidade.</label>
				<br />
				<br />
		
                
			<center><a href="gabarito.html" style="width:400;height:100" > <button  id="signin" class="">Enviar!</button></a></center>	  	 
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
