<?php 
session_start();
$_SESSION['teste']=9;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 10ºprova</h1>
		 
			<a href="../10/mes10.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
			
			
			
			
			<p></p>
			<p>1)Relacione as colunas quanto às funções de que:</p>
			<p>I – Conjunção coordenada explicativa</p>
			<p>II – Conjunção coordenada alternativa</p>
			<p>III – Pronome interrogativo</p>
			<p>IV – Substantivo</p>
			<p>V – Interjeição</p>
			<p></p>
			
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A)  ( ) Trabalhe muito, que alcançará o sucesso.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B)( ) Está notícia tem um quê de fantasiosa.</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C)   ( ) Um que outro cliente, atraído pela promoção, entrou na loja hoje</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D) ( ) Quê! Não acredito que ela fez isso!  .</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E)( ) Que perguntas foram feitas ao professor?</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<p> 2) Assinale a única alternativa em que “que” é uma conjunção subordinativa integrante..</p>
				
				<p></p>
				
				
			<label>
				<input type="radio" name="questao2" value="a" /> A) ) Que notícia animadora você acaba de me dar!</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B)( ) Ele me olhou com um quê de ironia.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) ( ) Que estúpido fui em acreditar naquela proposta!.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D ( ) Queremos que todos compareçam ao casamento..</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)( ) Ficamos tão contentes com a música, que não nos importamos com o ambiente da apresentação..</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3) Entre a sociedade, a empresa e o Estado, está o profissional contábil, que, por sua vez, é o elo entre Fisco e contribuinte. É de fundamental importância que esse profissional aprimore seu entendimento tributário, percebendo sua necessidade. Ratifica-se, assim, o conceito de que a conscientização tributária pode representar um ponto de partida para a formação cidadã como uma das formas eficazes de atender às demandas sociais, com maior controle sobre a coisa pública. (L. 45-53)</p>
				
				<p></p>
				<p>As ocorrências do QUE no período acima classificam-se, respectivamente, como</p>
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A)  ( ) pronome relativo – pronome relativo – pronome relativo</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B) ( ) pronome relativo – conjunção – conjunção</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C)( ) conjunção – conjunção – conjunção.</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D( ) conjunção – pronome relativo – pronome relativo</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E) ( ) pronome relativo – pronome relativo – conjunção</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4)  A palavra anoitecer é formado pelo seguinte processo de formação de palavras:</p>

 
			
			
			<br> </br>
			<p></p>
			
			<label>
				<input type="radio" name="questao4" value="a" /> A) derivação prefixal</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B) derivação sufixal</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C) derivação parassintética</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)derivação regressiva</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)derivação imprópria </label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5)Classifique as palavras de acordo com o processo de derivação ou de composição.  </p>
			<p></p>
			
			
			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A)passatempo</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B) chuvisco</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C)  audiovisual</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D) paraquedas</label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e)antebraço</label>
				<br />
				<br />
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) Qual a única alternativa abaixo que tem apenas palavras formadas por composição por justaposição.: </p>


			

			<label>
				<input type="radio" name="questao6" value="a" /> A) A café com leite, guarda-chuva, pontapé</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)vinagre, aguardente, planalto

...</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) escolarização, desigualdade, abençoar.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) girassol, vaivém, embora

.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E) malmequer, fidalgo, pernalta.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7) Sobre o conto O espelho, de Machado de Assis, assinale com V (verdadeiro) ou F (falso) as seguintes afirmações. ( ) Jacobina, o casmurro cavalheiro, expõe aos eloquentes investigadores de coisas metafísicas sua teoria sobre as duas almas humanas. ( ) O alferes, sozinho em casa, precisa despir-se da farda para ver-se nitidamente no espelho. ( ) A nomeação do alferes para a guarda nacional já era esperada por todos, uma vez que vinha de família nobre. ( ) A leitura do conto permite refletir sobre vaidade, reconhecimento público e desigualdade social. A sequência correta de preenchimento dos parênteses, de cima para baixo, é </p>
				
			<p></p>
			<p></p>
			<p></p>
			
			<label>
				<input type="radio" name="questao7" value="a" /> A)  V – F – F – V.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B)F – V – V – F</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)F – V – F – V</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)F – F – V – F</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E)V – V – F – V</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8Aponte a alternativa cujo conteúdo não se aplica ao Arcadismo.</p>
				
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)  Desenvolvimento do gênero épico, registrando o início da corrente indianista na poesia brasileira.</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) Presença da mitologia grega na poesia de alguns poetas desse período.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C) Propagação do gênero lírico em que os poetas assumem a postura de pastores e transformam a realidade num quadro idealizado..</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D) Circulação de manuscritos anônimos de teor satírico e conteúdo político.</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E)Penetração de tendência mística e religiosa, vinculada à expressão de ter ou não fé..</label>
				<br />
				<br />
		
                
				<center><a href="gabarito.html" style="width:400;height:100" > <button  id="signin" class="">Enviar!</button></a></center>	  	 
			 
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
