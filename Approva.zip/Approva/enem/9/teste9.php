<?php 
session_start();
$_SESSION['teste']=8;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 9ºprova</h1>
		 
			<a href="../9/mes9.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
			
			
			
			
			<p></p>
			<p>1)O paralelismo sintático e a correção gramatical do texto CG4A1CCC seriam preservados se o segmento “a perseguição política, racial ou religiosa” (ℓ. 7 e 8) fosse substituído por</p
			<p></p>
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A)  a perseguição política, de raça, ou por religião.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B)a perseguição por política, de raça ou pela religião.</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C)   ser perseguido politicamente, por raça, e de religião.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D) a perseguição por posição política, por raça ou por religião.   .</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E)a perseguição politicamente, de raça e de religiosidade.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<p> 2) Assinale a alternativa que, e, conformidade com a norma-padrão, preenche adequadamente as lacunas do período “Nas próximas semanas, o plantão da enfermeira será, de quarta-feira _ domingo, das 8h _ 14h”.</p>
				
				<p></p>
				
				
			<label>
				<input type="radio" name="questao2" value="a" /> A)a e às.</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B) à e às.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) a e as..</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D)à e as.</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)a e a.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3) Para responder à questão, leia o fragmento do conto “Negrinha”, de Monteiro Lobato.</p>
				<p>“Negrinha era uma pobre órfã de sete anos. Preta? Não; fusca, mulatinha escura, de cabelos ruços e olhos assustados. Nascera na senzala, de mãe escrava, e seus primeiros anos vivera-os pelos cantos escuros da cozinha, sobre velha esteira e trapos imundos. Sempre escondida, que a patroa não gostava de crianças.</p>
				
				<p></p>
				<p>E tudo se esvaiu em trevas.
Depois, vala comum. A terra papou com indiferença aquela carnezinha de terceira – uma miséria, trinta quilos mal pesados…
E de Negrinha ficaram no mundo apenas duas impressões. Uma cômica, na memória das meninas ricas.</p>
				<p– “Lembras-te daquela bobinha da titia, que nunca vira boneca?”</p>
				<p>Outra de saudade, no nó dos dedos de dona Inácia.</p>
				<p>– “Como era boa para um cocre!…”</p>
				<p>Considerando o fragmento anterior, é correto afirmar:</p>
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A) Em “Negrinha”, conto-título de livro de Monteiro Lobato, editado em 1920, o autor apresenta, de forma crítica e mordaz, o tratamento cruel a que é submetida a pequena escrava, maltratada até a morte.</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B)Para o pré-modernista Monteiro Lobato, a infância é um período a ser celebrado pela alegria e vontade de viver, tema que anima o conto “Negrinha”. </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C)Como escritor romântico, Monteiro Lobato cria a personagem Negrinha como aquela que dá alegrias a Dona Inácia, sua patroa, por estar sempre a seu lado.</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D)Negrinha é uma das personagens mais marcantes da literatura infantil de Monteiro Lobato, o autor que inaugurou o gênero no Brasil.</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E) No conto “Negrinha”, Monteiro Lobato relembra uma pequena companheira de infância, vizinha das terras de seu avô.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4)  frase que apresenta pontuação inteiramente adequada é:</p>

 
			
			
			<br> </br>
			<p></p>
			
			<label>
				<input type="radio" name="questao4" value="a" /> A)  Ainda que tenha se aproximado, dos poetas concretos, Paulo Leminski deixou uma obra poética, que não se reduz ao concretismo, mas que é caracterizada antes de tudo, por uma dicção extremamente pessoal, avessa a todas as tentativas de rotulação.</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B) Ainda que tenha se aproximado dos poetas concretos, Paulo Leminski deixou uma obra poética que não se reduz ao concretismo, mas que é caracterizada, antes de tudo, por uma dicção extremamente pessoal, avessa a todas as tentativas de rotulação.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)Ainda, que tenha se aproximado dos poetas concretos, Paulo Leminski deixou uma obra poética que não se reduz ao concretismo, mas, que é caracterizada, antes de tudo por uma dicção, extremamente pessoal, avessa a todas as tentativas de rotulação.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)Ainda que tenha se aproximado dos poetas concretos, Paulo Leminski, deixou uma obra poética, que não se reduz ao concretismo mas que é caracterizada, antes de tudo, por uma dicção extremamente pessoal avessa, a todas as tentativas de rotulação..</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)Ainda que tenha se aproximado dos poetas, concretos, Paulo Leminski deixou uma obra poética que, não se reduz ao concretismo, mas que é caracterizada antes de tudo por uma dicção extremamente pessoal, avessa a todas, as tentativas de rotulação.  </label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5)Está inteiramente correta a pontuação do seguinte período:  </p>
			<p></p>
			
			
			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A)Não é fácil − confessemos logo − estabelecer uma clara linha divisória entre o que há de virtuoso na confiança, reconhecida como atividade positiva e criativa, e o que há de meritório em desconfiar, quando isso significa problematizar uma decisão.</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  Não é fácil, confessemos logo, estabelecer uma clara linha divisória: entre o que há de virtuoso na confiança reconhecida como atividade positiva, e criativa, e o que há de meritório em desconfiar, quando isso significa problematizar uma decisão.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C)  Não é fácil, confessemos logo: estabelecer uma clara linha divisória, entre o que há de virtuoso na confiança reconhecida, como atividade positiva e criativa, e o que há de meritório em desconfiar quando, isso, significa problematizar uma decisão.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D)Não é fácil, confessemos logo estabelecer, uma clara linha divisória, entre o que há de virtuoso, na confiança reconhecida, como atividade positiva e criativa, e o que há de meritório em desconfiar, quando isso significa problematizar uma decisão.</label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e) Não é fácil − confessemos logo − estabelecer uma clara linha divisória, entre o que há de virtuoso, na confiança reconhecida como atividade positiva e criativa, e o que há de meritório, em desconfiar quando isso significa problematizar uma decisão.</label>
				<br />
				<br />
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) Está plenamente adequada a pontuação do seguinte período: </p>


			

			<label>
				<input type="radio" name="questao6" value="a" /> A) Acredita-se sobretudo entre os estudiosos da linguagem, que por não haver dois sinônimos perfeitos, há que se empregar com toda a precisão os vocábulos de uma língua, ainda que com isso, se corra o risco de passar por pernóstico.</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)Acredita-se, sobretudo entre os estudiosos da linguagem que, por não haver dois sinônimos perfeitos há que se empregar, com toda a precisão, os vocábulos de uma língua ainda que com isso, se corra o risco de passar por pernóstico.

...</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) Acredita-se sobretudo entre os estudiosos da linguagem que, por não haver dois sinônimos perfeitos, há que se empregar com toda a precisão, os vocábulos de uma língua ainda que, com isso, se corra o risco de passar por pernóstico.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) EAcredita-se, sobretudo, entre os estudiosos da linguagem, que, por não haver dois sinônimos perfeitos, há que se empregar com toda a precisão, os vocábulos de uma língua, ainda que com isso, se corra o risco de passar por pernóstico.

.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E) Acredita-se, sobretudo entre os estudiosos da linguagem, que, por não haver dois sinônimos perfeitos, há que se empregar com toda a precisão os vocábulos de uma língua, ainda que com isso se corra o risco de passar por pernóstico...</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7) Das redações abaixo, assinale a que não está pontuada corretamente::</p>
				
			<p></p>
			<p></p>
			<p></p>
			
			<label>
				<input type="radio" name="questao7" value="a" /> A)  Os candidatos, em fila, aguardavam ansiosos o resultado do concurso..</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B)Em fila, os candidatos, aguardavam, ansiosos, o resultado do concurso..</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)Ansiosos, os candidatos aguardavam, em fila, o resultado do concurso</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)Os candidatos ansiosos aguardavam o resultado do concurso, em fila</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E)Os candidatos aguardavam ansiosos, em fila, o resultado do concurso.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Aponte a alternativa que justifica corretamente o emprego das vírgulas na seguinte frase:</p>
				
			<p>“Guri que finta banco, escritório, repartição, fila, balcão, pedido de certidão, imposto a pagar.”</p>
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)  Separar o aposto.</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) Separar o vocativo.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C) Separar orações coordenadas assindéticas.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D) Separar oração subordinada adverbial da oração principal.</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E)Separar palavras com a mesma função sintática.</label>
				<br />
				<br />
		
                
				<center><a href="gabarito.html" style="width:400;height:100" > <button  id="signin" class="">Enviar!</button></a></center>	  	 
				 
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
