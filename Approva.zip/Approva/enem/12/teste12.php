<?php 
session_start();
$_SESSION['teste']=11;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
         <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 12ºprova</h1>
		 
			<a href="../12/mes12.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" method = "post" action="../Script/teste_mensal.php">
			
			<p></p>
			<p>1) A regência verbal está errada em: </p>
			
			<p></p>
			
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) Esqueceu-se do endereço.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B)Não simpatizei com ele.</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C)   O filme a que assistimos foi ótimo.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D) Faltou-me completar aquela página..</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E)Aspiro um alto cargo político.. </LABEL>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<p> 2) Observe a regência verbal e assinale a opção falsa:</p>
				
				<p></p>
				
				
			<label>
				<input type="radio" name="questao2" value="a" /> A)    Avisaram-no que chegaríamos logo.</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B)Informei-lhe a nota obtida.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) Os motoristas irresponsáveis, em geral, não obedecem aos sinais de trânsito.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D)Há bastante tempo que assistimos em São Paulo.  .</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E) Muita gordura não implica saúde. </label>
			
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3) Tendo em vista que “as gírias” compõem o quadro de variantes linguísticas ligadas ao aspecto sociocultural, analise os excertos a seguir, indicando o significado de cada termo destacado de acordo com o contexto:

</p>


				
				<p></p>
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A)  Possivelmente não iremos à festa. Lá, todos os convidados são patricinhas e mauricinhos!
</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B) Nossa! Como meu pai é careta! Não permitiu que eu assistisse àquele filme.
</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C)Os namoros resultantes da modernidade baseiam-se somente no ficar.
</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D)  E aí mano? Estás a fim de encontrar com uma mina hoje? A parada vai bombar!
</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E) Aquela aula de matemática foi péssima, não saquei nada daquilo que o professor falou.   
</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4)Os enunciados linguísticos em evidência encontram-se grafados na linguagem coloquial. Reescreva-os de acordo com o padrão culto da linguagem.</p>

 
			
			
			<br> </br>
			<p></p>
			
			<label>
				<input type="radio" name="questao4" value="a" /> A) ) Os livros estão sobre a mesa. Por favor, devolve eles na biblioteca.</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B) Falar no celular é uma falha grave. A consequência deste ato pode ser cara.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)Me diga se você gostou da surpresa, pois levei muito para preparar ela..</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)No aviso havia o seguinte comentário: Não aproxime-se do alambrado. Perigo constante..</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)Durante a reunião houveram reclamações contra o atraso do pagamento dos funcionários. </label>
				<br />
				<br />
				
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5)A Semana de arte moderna, ocorrida em 1922, inaugurou o movimento modernista no Brasil. A primeira fase do modernismo literário brasileiro, que durou de 1922 a 1930, teve como principal característica:</p>
			<p></p>

			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A) uso de poemas de forma fixa, como o soneto.</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  linguagem rebuscada e acadêmica.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C) valorização das raízes culturais brasileiras.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D) pessimismo e oposição ao romantismo.</label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e)foco em temas relacionados com a colonização</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) Muitos escritores fizeram parte da primeira geração modernista no Brasil, exceto: </p>

			

			<label>
				<input type="radio" name="questao6" value="a" /> A) oMário de Andrade</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)Manuel Bandeira

...</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) Cassiano Ricardo</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D)  Carlos Drummond de Andrade

.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E)  Alcântara Machado.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7)A biosfera, que reúne todos os ambientes onde se desenvolvem os seres vivos, divide-se em unidades menores chamadas ecossistemas, que podem ser uma floresta, um deserto e até um lago. Um ecossistema tem múltiplos mecanismos que regulam o número de organismos dentro dele, controlando sua reprodução, crescimento e migrações.</p>
			<p>DUARTE, M. O guia dos curiosos. São Paulo: Companhia das Letras, 1995.</p>
			<p></p>
			<p>Predomina no texto a função da linguagem:</p>
			
			<label>
				<input type="radio" name="questao7" value="a" /> A) emotiva, porque o autor expressa seu sentimento em relação à ecologia.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B)fática, porque o texto testa o funcionamento do canal de comunicação..</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)poética, porque o texto chama a atenção para os recursos de linguagem..</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)conativa, porque o texto procura orientar comportamentos do leitor.</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E)referencial, porque o texto trata de noções e informações conceituais.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Alguns dos maiores expoente da estética romântica em Portugal no século XIX foram:.</p>
				
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)Castro Alves, Almeida Garret e Alexandre Herculano</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) Cesário Verde, Álvares de Azevedo e Castro Alves.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)  Eça de Queiroz, Camilo Castelo Branco e Vitor Hugo..</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D) Stendhal, Antero de Quental e Fagundes Varela.</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E)Almeida Garret, Alexandre Herculano e Camilo Castelo Branco...</label>
				<br />
				<br />
		
                
			<center><button  id="signin" type='submit'>Enviar!</button></center>	  
				 
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
