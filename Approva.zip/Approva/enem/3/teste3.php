<?php 
session_start();
$_SESSION['teste']=2;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	
	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 3ºprova</h1>
		 
			<a href="../3/mes3.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>				  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteudo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" method = "post" action="../Script/teste_mensal.php">
			
			
			<p>1)Sobre a obra “Os Bruzundangas”, de Lima Barreto, marque V ou F nas afirmações a seguir: ( ) O narrador em “Os Bruzundangas” é um jornalista, que conheceu a Bruzundanga através de uma viagem, e esse jornalista deixa patente sua comunicação com o público mencionando as notícias emitidas por ele sobre essa exótica nação.</p>
			<p></p>
			<br> ( ) O gênero textual predominante é o da crônica satírica. Seus traços são perceptíveis na linguagem cotidiana, próxima do leitor, em que a obra é apresentada e no trabalho do autor com os detalhes.</br>
			<p></p>
			<br> ( )O narrador é uma imagem de autor e essa imagem de autor é um homem de imprensa.</br>
			<p></p>
			<br>( ) Afonso Henriques de Lima Barreto pertence ao Pré-modernismo, um período de transição em que os autores, por não pertencerem a nenhuma estética, e a todas ao mesmo tempo, não podem ser enquadrados como velhos (tradicionais) nem como novos (modernistas). </br>]
			<p></p>
			<br> A sequência correta é: </br>
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) ( ) F, F, V, V;.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B) ( ) V, V, V, V; </label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C) ( ) V, F, V, F;label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D)( ) F, V, F, V;.</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E) ( ) V, V, F, F.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>

				<p> 2)  Metonímia é a figura de linguagem que consiste no emprego de um termo por outro, havendo sempre uma relação entre os dois. A relação pode ser de causa e efeito, de continente e conteúdo, de autor e obra ou da parte pelo todo. Assinale a alternativa em que essa figura ocorre:</p>
				<p></p>
				
				<p></p>
				
			<label>
				<input type="radio" name="questao2" value="a" /> A) Achando aquilo um desaforo.</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B) Miquelina ficou abobada com o olhar parado.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) E as mãos batendo nas bocas</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D)Calções negros corriam, pulavam.</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)Palhetas subiram no ar.</label>
				<br />
				<br />
						
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3)Nas conversas diárias, utiliza-se frequentemente a palavra “próprio” e ela se ajusta a várias situações. Leia os exemplos de diálogos: </p>
				<p></p>
				<br> I – A Vera se veste diferente! – É mesmo, é que ela tem um estilo próprio. </br>
				<br>II – A Lena já viu esse filme uma dezena de vezes! Eu não consigo ver o que ele tem de tão maravilhoso assim. – É que ele é próprio para adolescente.  </br>
				<br> III – Dora, o que eu faço? Ando tão preocupada com o Fabinho! Meu filho está impossível! – Relaxa, Tânia! É próprio da idade. Com o tempo, ele se acomoda. </br>
				<br>Nas ocorrências I, II e III, “próprio” é sinônimo de, respectivamente,  </br>
				<p></p>
				
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A) adequado, particular, típico. .</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B) peculiar, adequado, característico. </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C) conveniente, adequado, particular. .</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D) adequado, exclusivo, conveniente. .</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E)peculiar, exclusivo, característico. </label>
				<br />
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4)Leia o trecho da música “Pedro pedreiro”, de Chico Buarque: </p>
			<p>Pedro pedreiro penseiro esperando o trem</p>
				<p>Manhã parece, carece de esperar também</p>
				<p>Para o bem de quem tem bem de quem não tem vintém</p>
				<p>Pedro pedreiro fica assim pensando […]</p>
			<br> </br>
			<p></p>
			<p> No trecho lido, há uma palavra que destoa do vocabulário formal. A palavra penseiro pode ser classificada como:</p>
			<label>
				<input type="radio" name="questao4" value="a" /> A) figura de linguagem.</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B)figura de sintaxe ou figura de construção.   </label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)neologismo.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)	onomatopeia.</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E) hibridismo.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5) Neologismo pode ser definido como:    </p>
			<p></p>
			<br>Profissão de fé  </br>
			<p
			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A) o uso de qualquer recurso arcaico da língua; </label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  uso de palavras que infringem as regras atuais da grafia;</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C) Criação de palavras para atender às necessidades culturais, científicas e da comunicação de um modo geral.   </label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D)  palavras ou expressões, que, por diversas razões, saem de uso e acabam esquecidas por uma comunidade linguística, embora permaneçam em comunidades mais conservadoras. </label>
				<br/>
				<label>
				<input type="radio" name="questao5" value="e" /> E) É o emprego de palavras, expressões e construções alheias ao idioma que a ele chegam por empréstimos tomados de outra língua.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6)Qual das opções abaixo apresenta o sentido figurado:   </p>
			<p></p>
			<label>
				<input type="radio" name="questao6" value="a" /> A) As apostilas estão com preços exorbitantes.</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)  Não conseguimos o atendimento no banco. </label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) O funcionário estava muito confuso com os dados.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) Ele foi muito doce e atencioso comigo.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E)  No caminho de casa, encontramos um filhote de gato..</label>
				<br />
				<br />
					
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7)Indique se as orações abaixo apresentam o sentido denotativo (D) ou conotativo (C). </p>
				<p> 1. ( ) Meu tio era muito rico e nadava em ouro. </p>
			<p>2. ( ) O nadador brasileiro ganhou a medalha de ouro.</p>
			<p>3. ( ) Ela tinha um coração de pedra.</p>
			<p>4. ( ) Caiu e machucou a cabeça na pedra.</p>
			<p>5. ( ) Engoliu muito sapo no trabalho.</p>
			<p></p>
			<p></p
			<p></p>
			<p> A alternativa correta é:</p>
			<label>
				<input type="radio" name="questao7" value="a" /> A)C, C, D, D, C.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B) C, D, C, D, C</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)C, C, D, C, D</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D) D, C, C, D, D</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E) D, D, C, C, D</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Nos versos:  </p>
				<p>A“Bomba atômica que aterra

					<p>Pomba atônita da paz</p>

					<p>Pomba tonta, bomba atômica…”</p>
			<p></p>
			<p>A repetição de determinados elemento fônicos é um recurso estilístico denominado:</p>
			<label>
				<input type="radio" name="questao8" value="a" /> A) hiperbibasmo</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B)sinédoque </label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)metonímia.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D)aliteração</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E) metáfora</label>
				<br />
				<br />
			<center><a style="width:400;height:100" > <button  id="signin" type="submit">Enviar!</button></a></center>
			</div>	
			</div>
            </form>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
