<?php 
session_start();
$_SESSION['teste']=1;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}



	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 2ºprova</h1>
			
			<a href="../2/mes2.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
					<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" method = "post" action="../Script/teste_mensal.php">
			<br>Sermão da Sexagésima:</br>
			<br> Nunca na Igreja de Deus houve tantas pregações, nem tantos pregadores como hoje. Pois se tanto se semeia a palavra de Deus, como é tão pouco o fruto? Não há um homem que em um sermão entre em si e se resolva, não há um moço que se arrependa, não há um velho que se desengane. Que é isto? Assim como Deus não é hoje menos onipotente, assim a sua palavra não é hoje menos poderosa do que dantes era. Pois se a palavra de Deus é tão poderosa; se a palavra de Deus tem hoje tantos pregadores, por que não vemos hoje nenhum fruto da palavra de Deus? Esta, tão grande e tão importante dúvida, será a matéria do sermão. Quero começar pregando-me a mim. A mim será, e também a vós; a mim, para aprender a pregar; a vós, que aprendais a ouvir. </br>
			<br>VIEIRA, A. Sermões Escolhidos, v. 2. São Paulo: Edameris, 1965</br>
			
			
			<p>1) No Sermão da sexagésima, padre Antônio Vieira questiona a eficácia das pregações. Para tanto, apresenta como estratégia discursiva sucessivas interrogações, as quais têm por objetivo principal </p>
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) provocar a necessidade e o interesse dos fiéis sobre o conteúdo que será abordado no sermão.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B) conduzir o interlocutor à sua própria reflexão sobre os temas abordados nas pregações. </label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C) apresentar questionamentos para os quais a Igreja não possui respostas..</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D)inserir argumentos à tese defendida pelo pregador sobre a eficácia das pregações..</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E) questionar a importância das pregações feitas pela Igreja durante os sermões.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>

				<
				<p> 2)  No trecho abaixo, o narrador, ao descrever a personagem, critica sutilmente um outro estilo de época: o romantismo. </p>
				<p></p>
				<br> “Naquele tempo contava apenas uns quinze ou dezesseis anos; era talvez a mais atrevida criatura da nossa raça, e, com certeza, a mais voluntariosa. Não digo que já lhe coubesse a primazia da beleza, entre as mocinhas do tempo, porque isto não é romance, em que o autor sobredoura a realidade e fecha os olhos às sardas e espinhas; mas também não digo que lhe maculasse o rosto nenhuma sarda ou espinha, não. Era bonita, fresca, saía das mãos da natureza, cheia daquele feitiço, precário e eterno, que o indivíduo passa a outro indivíduo, para os fins secretos da criação.”</br>
				<br> ASSIS, Machado de. Memórias Póstumas de Brás Cubas.
Rio de Janeiro: Jackson, 1957.</br>
				<p></p>
				<p>A frase do texto em que se percebe a crítica do narrador ao romantismo está transcrita na alternativa:</p>
			<label>
				<input type="radio" name="questao2" value="a" /> A)... o autor sobredoura a realidade e fecha os olhos às sardas e espinhas...</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B) .. era talvez a mais atrevida criatura da nossa raça..</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C)Era bonita, fresca, saía das mãos da natureza, cheia daquele feitiço, precário e eterno, ...</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D)Naquele tempo contava apenas uns quinze ou dezesseis anos....</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)o indivíduo passa a outro indivíduo, para os fins secretos da criação</label>
				<br />
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3)Sobre o Arcadismo, estão corretas as seguintes proposições:</p>
				<p></p>
				<br>I. Originou-se em Minas Gerais, e seu aparecimento tem relação direta com o grande crescimento urbano verificado, no século XVIII, nas cidades mineiras, cuja vida econômica girava em torno da extração de ouro. </br>
				<p></p>
				<br>II. O Arcadismo foi uma manifestação artística que encontrou representantes também na música (o nascimento da ópera), na arquitetura (observa-se forte adesão ao estilo na construção de igrejas) e nas artes plásticas (destaque para as esculturas de Antônio Francisco Lisboa, o Aleijadinho). </br>
				<p></p>
				<br> III. O conceptismo e o cultismo são características da linguagem árcade. No conceptismo, há o jogo de ideias, a concisão e a ordem para convencer por meio do raciocínio; no cultismo, há o uso excessivo de figuras de linguagem e jogo de palavras, recursos literários que tinham como objetivo evidenciar a habilidade verbal do escritor,</br>
				<p></p>
				<br>IV. O movimento árcade tinha como principal intenção questionar a estética barroca, restabelecendo o equilíbrio, a harmonia e a simplicidade da literatura renascentista. Os primeiros árcades, jovens escritores portugueses, propuseram a eliminação dos rebuscamentos do Barroco, baseando-se nos preceitos do Iluminismo. </br>
				<p></p>
				<br> V. No Brasil, o Arcadismo manifestou-se pela primeira vez no ano de 1768 e representou o que de melhor se fez culturalmente no período colonial brasileiro. “Obras Poéticas”, de Cláudio Manuel da Costa, foi a primeira publicação desse novo estilo que pretendia, acima de tudo, que sua poesia fosse apreciada pelo seu valor poético ou literário.</br>
				<p></p>
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A) I, IV e V.</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B)II e III </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C) I, II e V.</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D) III e V.</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E)Apenas I está correta.</label>
				<br />
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4) Leia o texto para responder à questão. </p>
			<p></p>
			<br> Se o século XIX, marcado pelo progresso científico — genética, evolucionismo, positivismo, sociologia, racionalismo, etc. — motivou escolas literárias correspondentes — ___, ___, ___ —, propugnando uma descrição rígida, precisa e minuciosa, acarretou, em contrapartida, um momento de descrédito da ciência, uma reação quase radical, que propunha a diluição dos objetos e sentimentos no vago e indistinto, no inefável, abstrato e incorpóreo, ideal supremo do ___.</br>
			<br> (Lauro Junkes, 2016. Adaptado.)</br>
			<p></p>
			<p> Completam as lacunas do texto, respectivamente:</p>
			<label>
				<input type="radio" name="questao4" value="a" /> A)Realismo, Naturalismo, Romantismo — Simbolismo. </label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B)Romantismo, Simbolismo, Naturalismo — Realismo.   </label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)Realismo, Parnasianismo, Naturalismo — Simbolismo.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)	Realismo, Naturalismo, Romantismo — Parnasianismo..</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)Romantismo, Simbolismo, Naturalismo — Parnasianismo.</label>
				<br />
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5) Leia um trecho de um poema de Olavo Bilac.    </p>
			<p></p>
			<br>Profissão de fé  </br>
			<p>
			“Torce, aprimora, alteia, lima
			A frase; e enfim,
			No verso de ouro engasta a rima,
			Como um rubim.
			Quero que a estrofe cristalina
			Dobrada ao jeito
			Do ourives, saia da oficina
			Sem um defeito”.
			</p>
			<p></p>
			<p> Os versos de Olavo Bilac, transcritos acima, representam o ideal literário do:</p>
			<label>
				<input type="radio" name="questao5" value="a" /> A) Barroco, no seu apreço pelos jogos de palavras que formassem antíteses.  </label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B) Arcadismo, em sua preferência pelos preceitos do Iluminismo adaptáveis à arte literária.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C) Modernismo, em sua constância por seguir as normas literárias tradicionais.   </label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D) Parnasianismo, em seu objetivo ideário de chegar à perfeição da criação poética. </label>
				<br/>
				<label>
				<input type="radio" name="questao5" value="e" /> E) Romantismo, em sua procura pela valorização da formulação linguística nacional</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6)Analise as orações subsequentes e, se necessário for, faça as alterações convenientes:     </p>
			<p></p>
			<label>
				<input type="radio" name="questao6" value="a" /> A) A menina pegou o ônibus correndo.</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B) Visitamos o centro folclórico e o teatro cuja qualidade artística é tamanha. </label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) A mãe viu o filho chegando em casa bem tarde.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) A candidata deixou a plateia emocionada. </label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E)  O psicólogo examinou o paciente preocupado.</label>
				<br />
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7)Censura moralista </p>
				<p>Há tempos que a leitura está em pauta. E, diz-se, em crise. Comenta-se esta crise, por exemplo, apontando a precariedade das práticas de leitura, lamentando a falta de familiaridade dos jovens com livros, reclamando da falta de bibliotecas em tantos municípios, do preço dos livros em livrarias, num nunca acabar de problemas e de carências. Mas, de um tempo para cá, pesquisas acadêmicas vêm dizendo que talvez não seja exatamente assim, que brasileiros leem, sim, só que leem livros que as pesquisas tradicionais não levam em conta. E, também de um tempo para cá, políticas educacionais têm tomado a peito investir em livros e em leitura. </p>
			<p></p>
			<p> Os falantes, nos textos que produzem, sejam orais ou escritos, posicionam-se frente a assuntos que geram consenso ou despertam polêmica. No texto, a autora</p>
			<label>
				<input type="radio" name="questao7" value="a" /> A)ressalta a importância de os professores incentivarem os jovens às práticas de leitura.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B)critica pesquisas tradicionais que atribuem a falta de leitura à precariedade de bibliotecas. </label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)rebate a ideia de que as políticas educacionais são eficazes no combate à crise de leitura.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D) questiona a existência de uma crise de leitura com base nos dados de pesquisas acadêmicas.</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E) atribui a crise da leitura à falta de incentivos e ao desinteresse dos jovens por livros de qualidade.</label>
				<br />
				<br />
						
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Cárcere das almas   </p>
				<p>Ah! Toda a alma num cárcere anda presa,
				Soluçando nas trevas, entre as grades
				Do calabouço olhando imensidades,
				Mares, estrelas, tardes, natureza.
				Tudo se veste de uma igual grandeza
				Quando a alma entre grilhões as liberdades
				Sonha e, sonhando, as imortalidades
				Rasga no etéreo o Espaço da Pureza.
				Ó almas presas, mudas e fechadas
				Nas prisões colossais e abandonadas,
				Da Dor no calabouço, atroz, funéreo!
				Nesses silêncios solitários, graves,
				que chaveiro do Céu possui as chaves
				para abrir-vos as portas do Mistério?!</p>
			<p></p>
			<p>Os elementos formais e temáticos relacionados com o contexto cultural do Simbolismo encontrados no poema Cárcere das almas, de Cruz e Sousa, são:</p>
			<label>
				<input type="radio" name="questao8" value="a" /> A) a opção pela abordagem, em linguagem simples e direta, de temas filosóficos.</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B)a prevalência do lirismo amoroso e intimista em relação à temática nacionalista. </label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)o refinamento estético da forma poética e o tratamento metafísico de temas universais..</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D)a evidente preocupação do eu lírico com a realidade social expressa em imagens poéticas inovadoras..</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E) a liberdade formal da estrutura poética que dispensa a rima e a métrica tradicionais em favor de temas do cotidiano.</label>

				<br />
				<br />
                <center><a style="width:400;height:100" > <button  id="signin" type="submit">Enviar!</button></a></center>			
                </form>
                

				 
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
