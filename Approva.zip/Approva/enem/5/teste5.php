<?php 
session_start();
$_SESSION['teste']=4;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 5ºprova</h1>
		 
			<a href="../5/mes5.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>		
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
			
			
			
			<p>Os economistas são entendidos em mercado financeiro.<p>
			<p>Os economistas descreveram os efeitos dos juros.<p>
			<p>Os juros são altos.<p>
			<p>Todos os efeitos são arrasadores.</p>
			<p></p>
			<p>1)Assinale a opção que não atende corretamente às regras de concordância nominal, de acordo com a norma culta:<p>
			
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) Usavam ternos e gravatas claros.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B) Ofereci-lhe lindas rosas e lírios.</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C) Temos feito bastantes exercícios.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D)Elas estavam meias chateadas.</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E)Achei simpático o aluno e seus pais..</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				<
				<p> 2) Busque Amor novas artes, novo engenho,</p>
				<p>Para matar-me, e novas esquivanças;</p>
				<p>Que não pode tirar-me as esperanças,</p>
				<p>Que mal me tirará o que eu não tenho. </p>
				<p>Olhai de que esperanças me mantenho!</p>
				<p></p>
					<p>Vede que perigosas seguranças!</p>
					<p>Que não temo contrastes nem mudanças,</p>
					<p>Andando em bravo mar, perdido o lenho.</p>
				<p></p>
				
				<p>Mas, conquanto não pode haver desgosto</p>
					<p>Onde esperança falta, lá me esconde</p>
					<p>Amor um mal, que me mata e não se vê;</p>
				<p></p>
				<p>Que dias há que na alma me tem posto</p>
				<p>Um não sei quê, que nasce não sei onde,</p>
				<p>Vem não sei como, e dói não sei por quê.</p>
				<p></p>
				
				
				<p>Segundo os versos do poema, o eu lírico:</p>
				
				
			<label>
				<input type="radio" name="questao2" value="a" /> A)está à procura do Amor.</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B)está amando e cheio de esperanças.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) está seguro devido ao Amor.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D) está sem esperança.</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)N.D.A.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3)Ao se dirigir ao Amor, na primeira estrofe, percebe-se por parte do eu lírico um tom de:</p>
				<p></p>
				
				<p></p>
				
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A)  súplica</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B)desafio </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C) ameaça</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D) euforia .</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E) N.D.A</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4)No enunciado: “Virgílio, traga-me uma coca cola bem gelada!”, registra-se uma figura de linguagem denominada:

 </p>
			
			
			<br> </br>
			<p></p>
			
			<label>
				<input type="radio" name="questao4" value="a" /> A) anáfora</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B) personificação  </label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)antítese</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)catacrese.</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)nenhuma  </label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5) eufemismo está presente nos seguintes fragmentos, exceto:  </p>
			<p></p>
			
			<p
			
			
			<label>
				<input type="radio" name="questao5" value="a" /> A) "A mentira é uma verdade que se esqueceu de acontecer."  Mario Quintana.</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  “Não chorem! que não morreu!/ Era um anjinho do céu/ Que um outro anjinho chamou!/ Era uma luz peregrina,/ Era uma estrela divina/ Que ao firmamento voou!”. Álvares de Azevedo..</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C)  “Na chuva de cores/ da tarde que explode,/ a lagoa brilha./ A lagoa se pinta/ de todas as cores”. Carlos Drummond de Andrade. </label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D) “Quando a Indesejada das gentes chegar/ (Não sei se dura ou caroável),/ talvez eu tenha medo./ Talvez sorria, ou diga:/ - Alô, iniludível!”. Manuel Bandeira.</label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e) “Os amigos que me restam são de data recente; todos os antigos foram estudar a geologia dos campos santos.” Machado de Assis.</label>
				<br />
				<br />
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) Sobre o eufemismo, estão corretas: </p>
			<p></p>
			<br> I. Figura de linguagem que consiste no emprego de uma palavra ou expressão cuja principal intenção é expressar uma ideia com exagero.</br>
			<br> II. Figura de linguagem que consiste no emprego de uma palavra ou expressão no lugar de outra palavra ou expressão considerada desagradável ou chocante.</br>
			<br>III. O eufemismo é uma figura de linguagem que, além de ser empregada para amenizar um discurso cujo conteúdo semântico seja mais “pesado”, também pode ser utilizada com certa comicidade na intenção do falante, denotando ironias e ideologias presentes no discurso. </br>
			<br>IV. O eufemismo é a figura de linguagem mais adequada quando a intenção do falante é afirmar o contrário do que se quer dizer. </br>
			<br>V. O eufemismo é um importante recurso para a construção de sentidos de um texto, pois existem situações em que é preciso substituir palavras que, historicamente, carregam em seu significado conotações negativas. </br>
			<br> </br>
			
			<label>
				<input type="radio" name="questao6" value="a" /> A)   II, III e V.</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)  I, II e V.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C)  I e IV.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) III, IV e V.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E)  Apenas V.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7)No trecho “Basta chegar a Pequim para desnudar a farsa de que a China é o chão de fábrica do planeta, mas não tem acesso aos bens que produz.”, a expressão metafórica em destaque indica que os chineses</p>
				
			<p></p>
			<p></p>
			<p></p>
			
			<label>
				<input type="radio" name="questao7" value="a" /> A) produzem muito.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B) não são consumistas.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)produzem com pouca qualidade.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)não precisam daquilo que produzem.</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E) não produzem aquilo de que precisam..</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Qual a figura de linguagem presente na frase “As mãos que dizem adeus são pássaros que vão morrendo lentamente.”, de Mário Quintana? </p>
				
			<p></p>
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)  comparação</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) metáfora</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)metonímia</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D) eufemismo</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E) nenhuma.</label>
				<br />
				<br />
		
                
					<center><a href="gabarito.html" style="width:400;height:100" > <button  id="signin" class="">Enviar!</button></a></center>	 
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
