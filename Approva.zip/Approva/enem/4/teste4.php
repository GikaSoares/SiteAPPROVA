<?php 
session_start();
$_SESSION['teste']=3;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 4ºprova</h1>
		 
			<a href="../4/mes4.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			 
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" method = "post" action="../Script/teste_mensal.php">
			
			
			
			<p>Os economistas são entendidos em mercado financeiro.<p>
			<p>Os economistas descreveram os efeitos dos juros.<p>
			<p>Os juros são altos.<p>
			<p>Todos os efeitos são arrasadores.</p>
			<p></p>
			<p>1)Assinale a alternativa em que as informações acima foram reunidas adequadamente e sem ambiguidade.<p>
			
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) Os economistas que são entendidos em mercado financeiro descreveram os efeitos dos juros altos, que são arrasadores..</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B) Os economistas entendidos em mercado financeiro descreveram os efeitos que são arrasadores dos altos juros.</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C) 	Entendidos em mercado financeiro, os economistas descreveram os efeitos dos altos juros que são arrasadores.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D)Em relação aos juros altos, os economistas, entendidos em mercado financeiros, descreveram os efeitos que são arrasadores.</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E) Os economistas, que são entendidos em mercado financeiro, descreveram os efeitos, arrasadores, dos juros, que são altos.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 2) “Retórica dos namorados, dá-me uma comparação exata e poética para dizer o que foram aqueles olhos de Capitu. Não me acode imagem capaz de dizer, sem quebra da dignidade do estilo, o que eles foram e me fizeram. Olhos de ressaca? Vá, de ressaca. É o que me dá ideia daquela feição nova. Traziam não sei que fluido misterioso e enérgico, uma força que arrastava para dentro, como a vaga que se retira da praia, nos dias de ressaca. Para não ser arrastado, agarrei-me às outras partes vizinhas, às orelhas, aos braços, aos cabelos espalhados pelos ombros; mas tão depressa buscava as pupilas, a onda que saía delas vinha crescendo, cava e escura, ameaçando envolver-me, puxar-me e tragar-me.” </p>
				<p>ASSIS. Machado de. Dom Casmurro. São Paulo: Ática,1999. p.55 (fragmento)</p>
				
				<p></p>
				<p>Com Dom Casmurro, obra publicada em 1899, depois de Memórias Póstumas de Brás Cubas (1881) e de Quincas Borba (1891), Machado de Assis deixa marcas indeléveis de que a Literatura Brasileira vivia um novo período literário, bem diferente do Romantismo. Nessas obras, nota-se uma forma diferente de sentir e de ver a realidade, menos idealizada, mais verdadeira e crítica: uma perspectiva realista. O trecho apresentado acima representa essa perspectiva porque o narrador</p>
				
			<label>
				<input type="radio" name="questao2" value="a" /> A)exagera nas imagens poéticas traduzidas por “fluido misterioso”, “praia”, “cabelos espalhados pelos ombros” em uma realização imagética da mulher que o tragava como fazem as ondas de um mar em ressaca.</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B)deixa-se levar pelas ondas que saíam das pupilas de Capitu em um fluido, misterioso e enérgico, que o arrasta depressa como uma vaga que se retira da praia em dias de ressaca, não adiantando agarrar-se nem aos braços nem aos cabelos da moça.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) retira-se da praia como as vagas em dias de ressaca por não ser capaz de dizer a Capitu o que está sentindo ao olhá-la nos olhos sem quebrar a dignidade mínima daquele momento em que duas pessoas apaixonam-se.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D)solicita à “retórica dos namorados” uma comparação que seja, ao mesmo tempo, exata e poética capaz de descrever os olhos de Capitu, revelando a dificuldade de apresentar uma verdade que não estrague a idealização romântica.</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)ridiculariza a retórica dos românticos ao afirmar que os olhos de Capitu pareciam com uma ressaca do mar e, por isso, não seria capaz de descrevê-los de maneira poética, traduzindo, assim, o realismo literário de sua época.</label>
				<br />
				<br />
								
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3)No trecho “um mundo sem adjetivos é triste como um hospital no domingo” existe a seguinte figura de palavra: </p>
				<p></p>
				
				<p></p>
				
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A)  Catacrese.</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B)Comparação </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C) Antonomásia.</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D) Sinédoque .</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E) Metáfora</label>
				<br />
				<br />
				
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4)Todos os enunciados a seguir apresentam uma estrutura comparativa, EXCETO: </p>
			
			
			<br> </br>
			<p></p>
			<
			<label>
				<input type="radio" name="questao4" value="a" /> A) “Optou por ensinar como proporcionar uma boa dieta com recursos escassos.”</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B) “Não é esdrúxulo como ser devorado por um jacaré.”  </label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)“... a presença dessa coisa chamada amor como motor, tanto dela como das pessoas em quem ela inoculava o mesmo vírus.”</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)“Também não é raro como cair no poço do elevador, como a atriz Anecy Rocha...</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E) nenhuma </label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5)Assinale a opção que apresenta o segmento do texto em que não ocorre a presença da ironia.   </p>
			<p></p>
			
			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A) “ Iniciei-me no exílio antropológico ”.</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  “ solicitei a uma respeitável figura do último reduto urbano ”.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C) “... uma atividade tão inútil quanto estúpida ”. </label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D)   “ Essa plausível hipótese levou o nosso intermediário ...”. </label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e) “... acreditou ter testemunhado dois cientistas em ação ”.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) Considere a sentença: “Marisa saiu de casa atrasada e perdeu o ônibus”. As duas orações do período estão unidas pela conjunção “e”, que, além de indicar adição, introduz a ideia de  </p>
			<p></p>
			<label>
				<input type="radio" name="questao6" value="a" /> A)  oposição</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)  condição</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) consequência</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) comparação.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E)   união</label>
				<br />
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7)No enunciado, lê-se: “A língua que falamos é um bem, se considerarmos “bens” “as coisas úteis ao homem”. O termo negritado, segundo Cunha e Cintra (2009), tem o valor de um (a):</p>
				
			<p></p>
			<p></p
			<p></p>
			<p> A alternativa correta é:</p>
			<label>
				<input type="radio" name="questao7" value="a" /> A) construção linguística que apresenta relação causal.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B) sintagma com sentido opinativo, que apresenta uma relação comparativa.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)conectivo com valor de condição, pois indica uma hipótese.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)vocábulo gramatical que serve para adicionar uma ideia à outra.</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E) Trata-se de uma próclise.</label>
				<br />
				<br />
				
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Identifique a alternativa em que ocorre um pleonasmo vicioso: </p>
				
			<p></p>
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)  Ouvi com meus próprios ouvidos.</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) A casa, já não há quem a limpe. </label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)Para abrir a embalagem, levante a alavanca para cima.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D)Bondade excessiva, não a tenho.</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E) Bondade excessiva, não a tenho.</label>
				<br />
				<br />
		
                
				<center><button  id="signin" type='submit'>Enviar!</button></center>	
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
