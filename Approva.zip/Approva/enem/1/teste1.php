<?php 
session_start();
$_SESSION['teste']=0;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}




	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 1º prova</h1>
		 
			<a href="../1/mes1.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" method = "post" action="../Script/teste_mensal.php">
			<br>(Enem - 2012) “Ele era o inimigo do rei”, nas palavras de seu biógrafo, Lira Neto. Ou, ainda, “um romancista que colecionava desafetos, azucrinava D. Pedro II e acabou inventando o Brasil”. Assim era José de Alencar (1829-1877), o conhecido autor de O guarani e Iracema, tido como o pai do romance no Brasil.</br>
            <br>Além de criar clássicos da literatura brasileira com temas nativistas, indianistas e históricos, ele foi também folhetinista, diretor de jornal, autor de peças de teatro, advogado, deputado federal e até ministro da Justiça. Para ajudar na descoberta das múltiplas facetas desse personagem do século XIX, parte de seu acervo inédito será digitalizada.</br>
			<br>História Viva, n.° 99, 2011.</br>
			
			
			<p>1) Com base no texto, que trata do papel do escritor José de Alencar e da futura digitalização de sua obra, depreende-se que: </p>
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) a digitalização dos textos é importante para que os leitores possam compreender seus romances.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B) o conhecido autor de O guarani e Iracema foi importante porque deixou uma vasta obra literária com temática atemporal. </label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C) a divulgação das obras de José de Alencar, por meio da digitalização, demonstra sua importância para a história do Brasil Imperial.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D) a digitalização dos textos de José de Alencar terá importante papel na preservação da memória linguística e da identidade nacional.</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E) o grande romancista José de Alencar é importante porque se destacou por sua temática indianista.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<br>CAPÍTULO LXXI</br>
				<br>O senão do livro </br>
				<br> Começo o arrepender-me deste livro. Não que ele me canse; eu não tenho que fazer; e, realmente, expedir alguns magros capítulos para esse mundo sempre é tarefa que distrai um pouco da eternidade. Mas o livro é enfadonho, cheira a sepulcro, traz certa contração cadavérica; vício grave, e aliás ínfimo, porque o maior defeito deste livro és tu, leitor. Tu tens pressa de envelhecer, e o livro anda devagar; tu amas a narração direita e nutrida, o estilo regular e fluente, e este livro e o meu estilo são como os ébrios, guinam à direita e à esquerda, andam e param, resmungam, urram, gargalham, ameaçam o céu, escorregam e caem...</br>
				<br>E caem! – Folhas misérrimas do meu cipreste, heis de cair, como quaisquer outras belas e vistosas; e, se eu tivesse olhos, dar-vos-ia uma lágrima de saudade. Esta é a grande vantagem da morte, que, se não deixa boca para rir, também não deixa olhos para chorar... Heis de cair.</br>
				<br>          Machado de Assis, Memórias Póstumas de Brás Cubas </br>
				
				<p> 2)  No contexto, a locução “Heis de cair”, na última linha do texto, exprime: </p>
				<p></p>
			<label>
				<input type="radio" name="questao2" value="a" /> A)resignação ante um fato presente</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B) suposição de que um fato pode vir a ocorrer.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C)certeza de que uma dada ação irá se realizar.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D)ação intermitente e duradoura.</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)desejo de que algo venha a acontecer.</label>
				<br />
				<br />
				

				
				<hr width = 100% size = “10” color= #96CDCD>
				<img src="../../img/met.jpeg" alt=":(" width=400 height=400   style="width:530px; height: 200px; top: 37px;"> 	
				<p>3)O argumento presente na charge consiste em uma metáfora relativa à teoria evolucionista e ao desenvolvimento tecnológico. Considerando o contexto apresentado, verifica-se que o impacto tecnológico pode ocasionar:</p>
				<p></p>
				<label>
				<input type="radio" name="questao3" value="a" /> A)o surgimento de um homem dependente de um novo modelo tecnológico.</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B)a mudança do homem em razão dos novos inventos que destroem sua realidade. </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C) a problemática social de grande exclusão digital a partir da interferência da máquina.</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D)a invenção de equipamentos que dificultam o trabalho do homem, em sua esfera social.</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E)o retrocesso do desenvolvimento do homem em face da criação de ferramentas como lança, máquina e computador..</label>
				<br />
				<br />
				

				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4) 
Todas as sentenças abaixo apresentam ambigüidades. Assinale a alternativa em que a ambigüidade não pode ser desfeita com a simples alteração na ordem das palavras.      </p>
			<p></p>
			<label>
				<input type="radio" name="questao4" value="a" /> A)As crianças comeram bolo e sorvete de chocolate</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B)Ele viu a moça com um binóculo.    </label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)Ela saiu da loja de roupa.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)	As crianças esconderam os brinquedos que encontraram no porão.</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)Acabaram de roubar o banco da entrada da universidade </label>
				<br />
				<br />
							
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5) Marque a alternativa em que haja um artigo definido e um artigo indefinido, respectivamente:    </p>
			<p></p>
			<label>
				<input type="radio" name="questao5" value="a" /> A) Roberta é a melhor aluna dessa classe.  </label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B) Gostaria de comprar um celular novo e a sandália daquela loja.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C) Uma boa noite de sono é a melhor maneira de evitar o estresse.   </label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D) A casa que comprei é um pouco antiga.</label>
				<br/>
				<label>
				<input type="radio" name="questao5" value="e" /> E) Nenhuma das alternativas anteriores. </label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6)Sobre as características do Arcadismo, é correto afirmar, exceto:     </p>
			<p></p>
			<label>
				<input type="radio" name="questao6" value="a" /> A) Os poetas árcades defendiam o bucolismo como estilo de vida no campo, longe dos centros urbanos. A vida pobre e feliz no ambiente campestre contrasta com a vida luxuosa e triste na cidade.</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B) Apego excessivo pela forma em detrimento do conteúdo. O Arcadismo defendeu a “arte pela arte”, um retorno aos ideais literários clássicos. </label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) Como expressão artística da burguesia, o Arcadismo veiculou também certos ideais políticos e ideológicos dessa classe, formulados pelo Iluminismo.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) O desejo de aproveitar o dia e a vida enquanto é possível, também conhecido como carpe diem.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E)  A poesia árcade apresentou um convencionalismo amoroso: não há variações emocionais de um poema para o outro nem de poeta para poeta, importando mais escrever poemas como os poetas clássicos escreviam.</label>
				<br />
				<br />
								
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 <img src="../../img/cono.jpeg" alt=":(" width=400 height=400   style="width:600px; height: 200px;top: 40px;"> 	
				<p> 7)O ápice da narrativa da tirinha está centrado no uso de significados diferentes para a mesma palavra, o que dependerá do contexto em que está inserida, como é o caso da palavra “barbero”. A essa propriedade damos o nome de      </p>
			<p></p>
			<label>
				<input type="radio" name="questao7" value="a" /> A)Antonímia.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B)Denotação. </label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)Polissemia.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D) Conotação.</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E) Paronímia.</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				<img src="../../img/mafalda.jpeg" alt=":(" width=400 height=400   style="width:530px; height: 200px; top: 37px;"> 
				<p>  8)O humor presente na tirinha decorre principalmente do fato de a personagem Mafalda     </p>
				<p></p>
			<label>
				<input type="radio" name="questao8" value="a" /> A) atribuir, no primeiro quadrinho, poder ilimitado ao dedo indicador.</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B)considerar seu dedo indicador tão importante quanto o dos patrões </label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)atribuir, no primeiro e no último quadrinhos, um mesmo sentido ao vocábulo “indicador”.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D)usar corretamente a expressão “indicador de desemprego”, mesmo sendo criança.</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E)atribuir, no último quadrinho, fama exagerada ao dedo indicador dos patrões</label>
				<br />
				<br />
				 <center><a style="width:400;height:100" > <button  type="submit" id="signin" class="">Enviar!</button></a></center>	
             </form>
		
			</div>	
			</div>
        <script src='codigo.js'></script>
            
	</body>
	
</html>
