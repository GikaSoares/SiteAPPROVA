<?php 
session_start();
$_SESSION['teste']=7;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 8ºprova</h1>
		 
			<a href="../8/mes8.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteudo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
			
			
			
			
			<p></p>
			<p>1)Assinale a alternativa em que há erro de pontuação:</p
			<p></p>
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A)  (  ) Era do conhecimento de todos a hora da prova, mas, alguns se atrasaram.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B)(  ) A hora da prova era do conhecimento de todos; alguns se atrasaram, porém..</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C (  ) Todos conhecem a hora da prova; não se atrasem, pois.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D) (  ) Todos conhecem a hora da prova, portanto não se atrasem.    .</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E)(  ) N.D.A</label>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				<
				<p> 2) Esta questão refere-se ao conto “A terceira margem do rio”, do livro Primeiras estórias, de João Guimarães Rosa.</p>
				<p>"De dia e de noite, com sol ou aguaceiros, calor, sereno, e nas friagens terríveis de meio-do-ano, sem arrumo, só com o chapéu velho na cabeça, por todas as semanas, e meses, e os anos – sem fazer conta do se-ir do viver."</p>
				<p></p>	
				<p>A expressão sublinhada é um exemplo das recriações linguísticas do autor. Seu sentido, com base no trecho citado, pode ser definido como:</p>
				
				<p></p>
				
				
			<label>
				<input type="radio" name="questao2" value="a" /> A)ação da natureza</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B) passagem do tempo</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) presença de esperança.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D) necessidade de cuidados</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E)n.d.a</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3)Esta questão refere-se ao conto “O espelho”, do livro Primeiras estórias, de João Guimarães Rosa.</p>
				<p>"− Se quer seguir-me, narro-lhe; não uma aventura, mas experiência, a que me induziram, alternadamente, séries de raciocínios e intuições."</p>
				
				<p></p>
				<p>A fala inicial do conto anuncia que a história combina gêneros textuais distintos.</p>
				<p>Além da narrativa, o outro gênero que se realiza nesse conto é o da:</p>
				<p></p>
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A)  dissertação</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B)reportagem </label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C)entrevista</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D)carta</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E)  n.d.a</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4) As expressões em negrito correspondem a um adjetivo, exceto em:</p>

 
			
			
			<br> </br>
			<p></p>
			
			<label>
				<input type="radio" name="questao4" value="a" /> A)  João Fanhoso anda amanhecendo sem entusiasmo.</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B) Demorava-se de propósito naquele complicado banho.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C)Os bichos da terra fugiam em desabalada carreira.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)Noite fechada sobre aqueles ermos perdidos da caatinga sem fim.</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)E ainda me vem com essa conversa de homem da roça.  </label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5)Assinale o item que só contenha preposições:  </p>
			<p></p>
			
			
			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A)durante, entre, sobre</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  com, sob, depois</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C)  para, atrás, por</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D)em, caso, após.</label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e) após, sobre, acima</label>
				<br />
				<br />
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) Concordância verbal incorreta: </p>


			

			<label>
				<input type="radio" name="questao6" value="a" /> A)  V. Ex.ª é generoso.</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B) Mais de um jornal comentou o jogo....</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C)  Elaborou-se ótimos planos.</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D) Eu e minha família fomos ao mercado.

.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E) Os Estados Unidos situam-se na América do Norte..</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7) Indique a alternativa correta:</p>
				
			<p></p>
			<p></p>
			<p></p>
			
			<label>
				<input type="radio" name="questao7" value="a" /> A) Tratavam-se de questões fundamentais.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B)Comprou-se terrenos no subúrbio.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)LPrecisam-se de datilógrafas.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)Reformam-se ternos..</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E)Obedeceram-se aos severos regulamentos..</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Elas _____ providenciaram os atestados, que enviaram _____ às procurações, como instrumentos _____ para os fins colimados. </p>
				
			<p></p>
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)  mesmas, anexos, bastantes</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) mesmo, anexo, bastante</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C) mesmas, anexo, bastante</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D) mesmo, anexos, bastante</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E) mesmas, anexos, bastante</label>
				<br />
				<br />
		
                
				<center><a href="gabarito.html" style="width:400;height:100" > <button  id="signin" class="">Enviar!</button></a></center>	  	 
				 
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
