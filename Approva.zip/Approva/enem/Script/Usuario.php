<?php
require_once("Func_Banco.php");
/*require_once("src/PHPMailer.php");
require_once("src/SMTP.php");
require_once("src/Exception.php");*/
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class Usuario{
    public function __construct($nome,$email,$senha){
        $this->nome=$nome;
        $this->senha=$senha;
        $this->email=$email;
    }
    public function __destruct(){
        echo "<hr>Destruição do Objeto Usuario";
    }
   #Para determinar a força da senha, vamos utilizar o zxcvbn do DropBox! Ver: https://github.com/bjeavons/zxcvbn-php
   /*public function ForcaDaSenha($senha,$par=NULL){

   }*/
    public function Cadastrar(){
        $banco= new Banco();
        $banco::inserir("Usuario","nome,email,senha","{$this->nome}','{$this->email}','{$this->senha}");
        header("Location: ../LOG/login.html");
    }
/*    public function enviar_email($msg,$msg2){
        $mail= new PHPMailer(true);
        try{
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'bhartolomeu1@gmail.com';
            $mail->Password ="B@rt0l0m3u";
            $mail->Port = 587;

            $mail->setFrom("bhartolomeu1@gmail.com");
            $mail->addAddress($this->email);

            $mail->ishtml(true);
            $mail->Subject = "Validar cadastro APPROVA";
            $mail->Body = $msg;		

            $mail->AltBody = $msg2;
            if($mail->send()) {
                echo "E-Mail enviado com sucesso";
            } else{
                echo "E-Mail não enviado";
            }
        }catch(Exception $e){
            echo "Erro ao enviar mensagem: {$mail->ErrorInfo}";
        }
    }*/
/*    public function permissao_cadastro(){
        
        $link="localhost/Approva/Script/cadastro2.php?nome={$this->nome}&email={$this->email}&senha={$this->senha}";
        echo $link."<hr>";
        $texto="<center><h2>VALIDAR CADASTRO</h2></center><br><p>Alguém(esperamos que você) tentou fazer cadastro no <i>site <b>Approva</b></i><br>Utilize o link a seguir para </p><a href= '".$link."'>Validar seu Cadastro</a>";
        echo $texto;
        $texto2="Alguém(esperamos que você) tentou fazer cadastro no site Approva, utilize o link a seguir para ".$link;
        $this->enviar_email($texto,$texto2);
    }*/

/*    public function permissao_rec_senha(){
        $link="localhost/Approva/Script/rec_senha2.php?email={$this->email}&senha={$this->senha}";
        echo $link."<hr>";
        $texto="<center><h2>VALIDAR CADASTRO</h2></center><br><p>Alguém(esperamos que você) tentou recuperar sua senha no <i>site <b>Approva</b></i><br>Utilize o link a seguir para </p><a href= '".$link."'>Validar seu Cadastro</a>";
        echo $texto;
        $texto2="Alguém(esperamos que você) tentou recuperar sua senha no site Approva, utilize o link a seguir para validar o cadastro: ".$link;
        $this->enviar_email($texto,$texto2);
    }
*/
    public function Login(){
        #Criação do objeto Banco para capturar informações do banco de dados com o método pegar()
        $banco= new Banco(); 
        $cript_senha=$banco::pegar("senha","Usuario","email='{$this->email}'");

        #Utilizamos o crypt() para verificar se a senha inserida é igual ao hash
        if (crypt($this->senha, $cript_senha[0])) {
            echo "<br>Você fez Login<br>";
            $a=$banco->pegar("*","Usuario","email='{$this->email}'");
            session_start();
            $_SESSION['id']=a[0];
            $_SESSION['nome']=a[1];
            $_SESSION['email']=a[2];
            $_SESSION['senha']=a[3];
            header("Location: ../AL/areaaluno.html");
        }
        else{
            echo "<br>Ops, você não preencheu um dos campos corretamente :(<br>";
            echo "<button href='/Approva/Paginas/login.html.html'>Voltar para Login</button>";
        }
   }
/*   public function Apagar_conta(){
        $banco= new Banco();
        $banco->apagar("Usuario","email='{$this->email}'");
        $nes=$banco->pegar("nome,email,senha","Usuario","email='{$this->email}'");
        echo"<br>Conta apagada, veja que os atributos não são impressos quando solicitados:<br><br>Nome: {$nes[0]}<br>E-Mail: {$nes[1]}<br>Senha: {$nes[2]}";
   }*/
   #Podemos usar o Google recaptcha para impedir robôs de entrarem no site, ver:https://www.youtube.com/watch?v=pewOo3kVc5s 
   /*public function SaiBot{
   }*/
} ?>
