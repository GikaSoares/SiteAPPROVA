

<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}




	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
        <link rel="stylesheet" href="../estilo.css">

	</head>    
	
    <body>

	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>RESULTADO TESTE ENEM</h1>
		 
			<a href="../1/mes1.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 
			<?php
require_once("Func_Banco.php");
session_start();
$a=[];
$a[0]=$_POST['questao1'];
$a[1]=$_POST['questao2'];
$a[2]=$_POST['questao3'];
$a[3]=$_POST['questao4'];
$a[4]=$_POST['questao5'];
$a[5]=$_POST['questao6'];
$a[6]=$_POST['questao7'];
$a[7]=$_POST['questao8'];
$c=[['d','c','a','e','d','b','b','c'],['a','a','b','c','d','b','d','c'],['b','d','b','c','c','d','b','d'],['e','d','b','a','e','c','c','c'],['d','c','a','d','c','e','a','c'],['a','c','a','a','a','b','a','b'],['c','a','a','b','a','b','c','d'],['a','a','a','e','a','c','c','a'],['d','a','a','e','a','e','b','e'],['d','d','b','c','a','a','a','e'],['c','b','e','e','c','e','c','e'],['e','a','e','c','c','d','e','e']];
/*for ($b=0;$b<8;$b++){
  echo "Questão ".$b.": ".$a[$b]."<br>";
}
echo "<hr>";
*/
$nota=0;
$mes=$_SESSION['teste']+1;
$mes2=$mes+1;

for ($b=0;$b<8;$b++){
    if($a[$b]==$c[$_SESSION['teste']][$b]){
        $nota++;
    }
}

/*echo "<hr>Data: ".date("Y-m-d")."<br>Nota: ".$nota."<br>mes: ".$mes."<br>mes2: ".$mes2."<br>";
echo "Link: ../{$mes2}/mes{$mes2}.html";*/

if ($nota>=4 and $mes==12){
    $banco=new Banco();
    $codigo=$_SESSION['id'].",".$mes.",".$nota.",'".date("Y-m-d")."'";
    $banco->inserir("Teste_Mensal","id_usuario,id_mes,nota,data_teste",$codigo);
    echo '<br><center><span style= "color:#96CDCD; text-align:center; font-size:40px;">Você Passou e Terminou o plano de estudos APPROVA!!!</span><br>';
    echo "<br><a id='signin' href='../../AL/areaaluno.html'>Próximo</a></center>";
}elseif ($mes<12 and $nota>=4){
    $banco=new Banco();
    $codigo=$_SESSION['id'].",".$mes.",".$nota.",'".date("Y-m-d")."'";
    $banco->inserir("Teste_Mensal","id_usuario,id_mes,nota,data_teste",$codigo);
    echo '<br><center><span style= "color:#96CDCD; text-align:center; font-size:40px;">Você Passou!!!</span><br>';
    echo "<br><a id='signin' href='../{$mes2}/mes{$mes2}.html'>Próximo</a></center>";
} else {
    echo '<br><br><center><span style= "color:#96CDCD; text-align:center; font-size:40px;" >INFELIZMENTE VOCÊ NÃO ATINGIU A NOTA MÍNIMA</span><br>';
    echo "<br><a id='signin' href='../{$mes}/mes{$mes}.html'> TENTE OUTRA VEZ</a></center>";
    //echo "<button id='signin' href='../{$mes}/mes{$mes}.html'> TENTE OUTRA VEZ</button></center>";
}

?>
	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>Hey vestibulando,</h1>

					<h2>Este foi seu desempenho: </h2>
<?php
                    echo "{$nota} de 8 questões!";
?>
                    <h2>Continue se dedicando!</h2>
					</div>

			</div>
			</div>

			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			
        <script src='codigo.js'></script>
            
	</body>
	
</html>
