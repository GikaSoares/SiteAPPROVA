<?php 
session_start();
$_SESSION['teste']=10;
?>
<!DOCTYPE html>
<html lang = 'pt-br'>
    <head>
    <meta charset = 'UTF-8'>
    <meta name = 'viewport' content = 'width-device-width, initial-scale-1.0'>
    <meta http-equiv = "X-UA-Compatible" content="ie=edge">

    <style>
	* {
	  box-sizing: border-box;
	}

	.row::after {
	  content: "";
	  clear: both;
	  display: table;
	  width: 20px;
	}

	[class*="col-"] {
	  float: left;
	  padding: 15px;
	}

	html {
	  font-family: normal 15pt 'Open Sans', sans-serif;
	}

	.titulo {
	  background-color: #00868B;
	  color: #ffffff;
	  padding: 15px;
	  
	} 
	
	.apresentacao {
	   background-color: #ffffff;
	   color: #00868B;
	   padding: 15px;
	   text-align: left;
	   
	}

	.info.gp {
	   background-color: #ffffff;
	   padding: 15px;
	   border-radius:25px;
       color: #00868B;
       text-align: center;
	   display: flex;

	}
	
	.info.gp.2 {
		background-color: #ffffff;
		display: flex;
		padding: 25px;
		color:#00868B;
		text-align: center;
		border-radius:25px;

	}
	
	.info.gp.3 {
		background-color: #33b5e5;
		color: #ffffff;
		display: flex;
		padding: 25px;
		text-align:justify
		border-radius:25px;

	}


	.footer {
	color:#58af9b;
	font-size: 20px;
	padding: 15px;
    font-style: italic;
    background-color:#fff;
	/* text-align: center; */
    height: 100px;
    border-radius:10px;
    box-shadow: 3px 3px 10px #777;
	}
	


	/* For mobile phones: */
	[class*="col-"] {
	  width: 100%;
	}
	
	


	@media only screen and (min-width: 600px) {
	  /* For tablets: */
	  .col-s-1 {width: 8.33%;}
	  .col-s-2 {width: 16.66%;}
	  .col-s-3 {width: 25%;}
	  .col-s-4 {width: 33.33%;}
	  .col-s-5 {width: 41.66%;}
	  .col-s-6 {width: 50%;}
	  .col-s-7 {width: 58.33%;}
	  .col-s-8 {width: 66.66%;}
	  .col-s-9 {width: 75%;}
	  .col-s-10 {width: 83.33%;}
	  .col-s-11 {width: 91.66%;}
	  .col-s-12 {width: 100%;}
	}
	@media only screen and (min-width: 768px) {
	  /* For desktop: */
	  .col-1 {width: 8.33%;}
	  .col-2 {width: 16.66%;}
	  .col-3 {width: 25%;}
	  .col-4 {width: 33.33%;}
	  .col-5 {width: 41.66%;}
	  .col-6 {width: 50%;}
	  .col-7 {width: 58.33%;}
	  .col-8 {width: 66.66%;}
	  .col-9 {width: 75%;}
	  .col-10 {width: 83.33%;}
	  .col-11 {width: 91.66%;}
	  .col-12 {width: 100%;}
	}
	</style>

        <title>Approva Língua Portuguesa e Literatura</title>
         <link rel="stylesheet" href="../../enem/estilo.css">

	</head>    
	
    <body>
	
			<div class="row">
			<div class="col-3 col-s-12 menu">		
			<div class="titulo">
			<h1>TESTE ENEM- 11ºprova</h1>
		 
			<a href="../11/mes11.html" style="width:400;height:100" > <button  id="signin" class="">Voltar</button></a>	
			<a href="../../hp/Hpatualizada.html" style="width:400;height:100" > <button  id="signin" class="">Pagina inicial</button></a>
			<img src="../../img/imgg.jpeg" alt=":(" width=250 height=250>			  
			</div>
			</div>


			<div class="col-6 col-s-12 menu">	
			<img src="../../img/enem.jpeg" alt=":(" width=509 height=302> 	
			</div>
	
		
			<div class="col-3 col-s-12 menu">
				
					<div class="box">
					<h1>CONCENTRA !!!</h1>
					<h2>Hey vestibulando, feche todas as outras abas!</h2>

					<h4>Se concentre em todo o conteúdo que estudou nessas semanas.</h4>
					<h4> Boa sorte!</h4>
			<img src="../../img/relogio2.jpeg" alt=":(" width=250 height=250> 
					</div>

			</div>
			</div>
			
			

			<div class="col-3 col-s-3 menu">
			 
			 
			 </div>
				  <div class="col-6 col-s-9 ">
				  
		 
			</p>
			 
			<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
			
			
			
			
			<p></p>
			<p>1)Assinale a alternativa em que se encontram preocupações estéticas da Primeira Geração Modernista:</p>
			
			<p></p>
			
			
			<p></p>
			<label>
				<input type="radio" name="questao1" value="a" />A) Principal corrente de vanguarda da Literatura Brasileira, rompeu com a estrutura discursiva do verso tradicional, valendo-se de materiais gráficos e visuais que transformaram a estrutura do poema.</label>
				</br>
				
				<label>
				<input type="radio" name="questao1" value="b" /> B)Busca pelo sentido da existência humana, confronto entre o homem e a realidade, reflexão filosófico-existencialista, espiritualismo, preocupação social e política, metalinguagem e sensualismo..</label>
				<br />
				
				<label>
				<input type="radio" name="questao1" value="c" /> C)  Os escritores de maior destaque da primeira fase do Modernismo defendiam a reconstrução da cultura brasileira sobre bases nacionais, revisão crítica de nosso passado histórico e de nossas tradições culturais, eliminação do complexo de colonizados e uso de uma linguagem própria da cultura brasileira.</label>
				<br />
				<label>
				<input type="radio" name="questao1" value="d" /> D) Amadurecimento da prosa, sobretudo do romance, enfoque mais direto dos fatos, influência da estética Realista-Naturalista do século XIX e caráter documental, como no livro Vidas secas, de Graciliano Ramos. .</label>
				<br/>
				<label>
				<input type="radio" name="questao1" value="e" /> E)n.d.a. </LABEL>
				<br />
				<br />
				
				<hr width = 100% size = “10” color= #96CDCD>
			<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<p> 2) Os principais nomes da primeira fase do Modernismo na Literatura foram:</p>
				
				<p></p>
				
				
			<label>
				<input type="radio" name="questao2" value="a" /> A)   Lima Barreto, Augusto dos Anjos e Oswald de Andrade.</label>
				</br>
				<label>
				<input type="radio" name="questao2" value="b" /> B)Mário de Andrade, Manuel Bandeira e Oswald de Andrade.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="c" /> C) Mário Quintana, Mário de Andrade e Patrícia Galvão.</label>
				<br />
				<label>
				<input type="radio" name="questao2" value="d" /> D Manuel Bandeira, Tarsila do Amaral e Lima Barreto...</label>
				<br/>
				<label>
				<input type="radio" name="questao2" value="e" /> E) n.d.a. </label>
			
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				<p>3) Em O cortiço, o caráter naturalista da obra faz com que

				o narrador se posicione em terceira pessoa, onisciente e onipresente,

				preocupado em oferecer uma visão crítico- analística dos fatos. A

				sugestão de que o narrador é testemunha pessoal e muito próxima dos

				acontecimentos narrados aparece de modo mais direto e explícito em:


				
				<p></p>
				
				
				<label>
				<input type="radio" name="questao3" value="a" /> A)  Fechou-se um entra-e-sai de marimbondos defronte daquelas cem casinhas ameaçadas pelo fogo.
</label>
				</br>
				<label>
				<input type="radio" name="questao3" value="b" /> B) Ninguém sabia dizê-lo; mas viam-se baldes que se despejavam sobre as chamas.
</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="c" /> C)Da casa do Barão saíam clamores apopléticos...
</label>
				<br />
				<label>
				<input type="radio" name="questao3" value="d" /> D) Bruxa surgiu à janela da sua casa, como à boca de uma fornalha acesa.
</label>
				<br/>
				<label>
				<input type="radio" name="questao3" value="e" /> E) Ia atirar-se cá para fora, quando se ouviu estalar o madeiramento da casa incendiada...
</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 4) Quanto à organização sintático-semântica do fragmento “Ninguém ama tanto a vida como a pessoa que envelhece”, é correto afirmar:</p>

 
			
			
			<br> </br>
			<p></p>
			
			<label>
				<input type="radio" name="questao4" value="a" /> A) ) As formas verbais “ama” e “envelhece” exigem complemento.</label>
				</br>
				<label>
				<input type="radio" name="questao4" value="b" /> B) O conectivo “como” introduz oração que expressa ideia de conformidade.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="c" /> C) Os termos “Ninguém” e “vida” exercem a mesma função sintática.</label>
				<br />
				<label>
				<input type="radio" name="questao4" value="d" /> D)A forma verbal “envelhece” tem como complemento o termo “pessoa”.</label>
				<br/>
				<label>
				<input type="radio" name="questao4" value="e" /> E)A oração “que envelhece” expressa ideia de restrição. </label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p> 5)Sobre a literatura produzida no primeiro século da vida colonial brasileira, é correto afirmar que:</p>
			<p></p>
			

			<p></p>
			
			<label>
				<input type="radio" name="questao5" value="a" /> A)É formada principalmente de poemas narrativos e textos dramáticos que visavam à catequese.</label>
				</br>
				<label>
				<input type="radio" name="questao5" value="b" /> B)  Inicia com Prosopopeia, de Bento Teixeira.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="c" /> C)  É constituída por documentos que informam acerca da terra brasileira e pela literatura jesuítica.</label>
				<br />
				<label>
				<input type="radio" name="questao5" value="d" /> D) Os textos que a constituem apresentam evidente preocupação artística e pedagógica.</label>
				<br/>
				<input type="radio" name="questao5" value="e" /> e)Descreve com fidelidade e sem idealizações a terra e o homem, ao relatar as condições encontradas no Novo Mundo.</label>
				<br />
				<br />
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				<p>  6) A famosa “Carta de achamento do Brasil”, mais conhecida como “A carta de Pero Vaz de Caminha”, foi o primeiro manuscrito que teve como objeto a terra recém-descoberta. Nela encontramos o primeiro registro de nosso país, feito pelo escrivão do rei de Portugal, Pero Vaz de Caminha. Podemos inferir, então, a seguinte intenção dos portugueses:</p>


			

			<label>
				<input type="radio" name="questao6" value="a" /> A) objetivavam o resgate de valores e conceitos sociais brasileiros.</label>
				</br>
				<label>
				<input type="radio" name="questao6" value="b" /> B)buscavam descobrir, através da arte, a história da terra recém-descoberta.

...</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="c" /> C) estavam empenhados em conhecer um pouco mais sobre a arte brasileira..</label>
				<br />
				<label>
				<input type="radio" name="questao6" value="d" /> D)  firmar um pacto de cordialidade com os nativos da terra descoberta.

.</label>
				<br/>
				<label>
				<input type="radio" name="questao6" value="e" /> E) explorar a tão promissora nova terra.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				 
				 
				<p> 7)Assinale a alternativa que completa adequadamente a asserção: </p>
			<p>O Romantismo, graças à ideologia dominante e a um complexo conteúdo artístico, social e político, caracteriza-se como uma época propícia ao aparecimento de naturezas humanas marcadas por</p>
			<p></p>
			<p></p>
			
			<label>
				<input type="radio" name="questao7" value="a" /> A) teocentrismo, hipersensibilidade, alegria, otimismo e crença.</label>
				</br>
				<label>
				<input type="radio" name="questao7" value="b" /> B)etnocentrismo, insensibilidade, descontração, otimismo e crença na sociedade.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="c" /> C)egocentrismo, hipersensibilidade, melancolia, pessimismo, angústia e desespero.</label>
				<br />
				<label>
				<input type="radio" name="questao7" value="d" /> D)teocentrismo, insensibilidade, descontração, angústia e desesperança.</label>
				<br/>
				<label>
				<input type="radio" name="questao7" value="e" /> E)egocentrismo, hipersensibilidade, alegria, descontração e crença no futuro.</label>
				<br />
				<br />
				
				<form id="questionario" name ="questionario" method = "post" action="resposta.php">
				
				<hr width = 100% size = “10” color= #96CDCD>
				
				
				<p>  8)Alguns dos maiores expoente da estética romântica em Portugal no século XIX foram:.</p>
				
			
			<label>
				<input type="radio" name="questao8" value="a" /> A)Castro Alves, Almeida Garret e Alexandre Herculano</label>
				</br>
				<label>
				<input type="radio" name="questao8" value="b" /> B) Cesário Verde, Álvares de Azevedo e Castro Alves.</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="c" /> C)  Eça de Queiroz, Camilo Castelo Branco e Vitor Hugo..</label>
				<br />
				<label>
				<input type="radio" name="questao8" value="d" /> D) Stendhal, Antero de Quental e Fagundes Varela.</label>
				<br/>
				<label>
				<input type="radio" name="questao8" value="e" /> E)Almeida Garret, Alexandre Herculano e Camilo Castelo Branco...</label>
				<br />
				<br />
		
                
			<center><a href="gabarito.html" style="width:400;height:100" > <button  id="signin" class="">Enviar!</button></a></center>	  	 
			  
			</div>	
			</div>
			
			
			
			
			
			
			

		
        <script src='codigo.js'></script>
            
	</body>
	
</html>
