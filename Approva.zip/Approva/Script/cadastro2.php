<pre>
<?php
    require_once("Usuario.php"); 
    require_once("Func_Banco.php");
    $usuario = new Usuario($_GET["nome"],$_GET["email"],$_GET["senha"]);

    echo "Seu nome é {$usuario->nome} , seu E-mail é {$usuario->email} e sua senha é {$usuario->senha}! <br>";//teste para ver se os dados chegaram

    $banco = new Banco();

    #INSERT
    $usuario->Cadastrar();
    echo "<hr>Cadastro feito";
        
    #SELECT
    $dados=$banco->pegar("id_usuario,nome,email,senha","Usuario","nome='{$usuario->nome}'");
    echo "<br>Seu id é: ".$dados[0]."<br>Seu nome é: ". $dados[1]."<br>Seu email é: ".$dados[2]."<br>Sua senha é: ".$dados[3]."!!!<br/>";#Imprimir os dados do select
    if (crypt($dados[3],"biah")){
        echo "Senha confirmada";
    }

    #DELETE
    #$usuario->Apagar_conta();
?>
</pre>
