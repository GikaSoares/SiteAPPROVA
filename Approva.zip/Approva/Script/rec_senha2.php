<?php
require_once("Usuario.php");
require_once("Func_Banco.php");
$usuario=new Usuario(NULL,$_GET["email"],$_GET["senha"]);
$banco=new Banco();
$banco->alterar("Usuario","senha",crypt($usuario->senha),"email='{$usuario->email}'");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Recuperar Senha</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link rel="stylesheet" href="../Design/style.css">
</head>
<body>
<div class="container">
    <h1>Senha Alterada com suscesso</h1><br>
    <button class="btn" href="../Paginas/login.html">Voltar para Página de Login</button>
</div>
</body>
</html>
