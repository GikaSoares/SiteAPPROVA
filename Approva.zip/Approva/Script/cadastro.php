<?php
require_once("Usuario.php"); 

$usuario= new Usuario($_POST["nome"],$email=$_POST["email"],crypt($_POST["senha"]));
echo "<br>Nome: ".$usuario->nome."<br>E-mail: ".$usuario->email."<br>Senha: ".$usuario->senha."<hr>";

if (crypt($usuario->senha,$_POST["conf_senha"])){
    if($usuario->nome != NULL and $usuario->email != NULL){
        /*$usuario->permissao_cadastro();*/
        $usuario->Cadastrar();
    }else{
        echo "<br><span>O campo nome ou email não foi preenchido corretamente</span>";
    }
}else{
    echo "<br><span>Senha não foi confirmada</span>";
}

?>
