<?php
require_once('Usuario.php');
session_start();
$banco=new Banco();
$banco->apagar("usuario","email={$_SESSION["email"]}");
echo "O usuario ".$_SESSION["nome"]." com E-mail ".$_SESSION["email"]." e senha ".$_SESSION["senha"]."acabou de ser apagado do banco";
session_unset();
session_destroy();
?>
