<?php
require_once("Usuario.php"); 
$email=$_POST["email"];
$senha=$_POST["senha"];
$usuario= new Usuario(NULL,$email,$senha);

echo "Seu email é: {$usuario->email}<br>Sua senha é: {$usuario->senha}";
$usuario->Login();

?>
