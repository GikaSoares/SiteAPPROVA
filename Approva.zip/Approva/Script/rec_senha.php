<?php
require_once("Usuario.php");
$usuario=new Usuario(NULL,isset($_POST["email"])?$_POST["email"]:"ERRO_EMAIL",isset($_POST["senha"])?$_POST["senha"]:"ERRO_SENHA");


if ($usuario->email=="ERRO_EMAIL" || $usuario->senha=="ERRO_SENHA"){
    echo "<label>Dados Inseridos de forma incorreta</label>";
}else{
  if ($usuario->senha<>$_POST["conf_senha"])
    echo "<label>Dados Inseridos de forma incorreta</label>";
  else{
    $usuario->permissao_rec_senha();  
  }
}
?>
