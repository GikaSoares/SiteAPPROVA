<?php 
class Banco{
	public function __destruct(){
		echo "<hr>Destruição do Objeto Banco";
	}
	function inserir($tabela,$atributos,$valores){
        #Abrir conexão
        $con=mysqli_connect( "localhost", "sysadmin", "bhartolomeu1" ) or die( ' Erro na conexão do Método INSERT!<br>'.mysqli_errno($con)." : ".mysqli_error($con));
        mysqli_select_db($con,"Approva")or die('Erro na seleção do Banco de Dados do Método INSERT!<br>'.mysqli_errno($con)." : ".mysqli_error($con));

        #Esse é o código para o insert (Apagar para melhorar otimização)
		$cod_insert="INSERT INTO {$tabela}({$atributos}) VALUES('{$valores}');";
        echo "<br>$cod_insert";
        #Finalmente a inserção no banco 
		mysqli_query($con, $cod_insert)or die('Erro na Query de INSERT!<br>'.mysqli_errno($con)." : ".mysqli_error($con));

        #Fechar conexão com o banco
        mysqli_close($con);
	}
	function pegar($atributos,$tabela,$identificacao){
        #Abrir conexão
        $con=mysqli_connect( "localhost", "sysadmin", "bhartolomeu1" ) or die( ' Erro na conexão do Método SELECT!<br>'.mysqli_errno($con)." : ".mysqli_error($con));
        mysqli_select_db($con,"Approva")or die('Erro na seleção do Banco de Dados do Método SELECT!<br>'.mysqli_errno($con)." : ".mysqli_error($con));


        #Esse é o código para o select (Apagar para melhorar otimização)
 		$cod_select = "SELECT {$atributos} FROM {$tabela} WHERE {$identificacao};";
        echo "<br><br>".$cod_select."<br><br>";
	    
	    //Por padrão, a Query do SELECT retorna um objeto. A função fetch_array transforma o objeto em lista
        $resultado = mysqli_query($con,$cod_select)or die('Erro na Query do SELECT!<br>'.mysqli_errno($con)." : ".mysqli_error($con));
        echo "<br><br>Var_dump: ".var_dump($resultado)."<br><br>";
        $resultado=mysqli_fetch_array($resultado);

        #Fechar conexão com o Banco
        mysqli_close($con);

	    return $resultado;
	}
	function apagar($tabela,$identificacao){
        #Abrir conexão
        $con=mysqli_connect( "localhost", "sysadmin", "bhartolomeu1" ) or die( ' Erro na conexão do Método DELETE!<br>'.mysqli_errno($con)." : ".mysqli_error($con));
        mysqli_select_db($con,"Approva")or die('Erro na seleção do Banco de Dados do Método DELETE!<br>'.mysqli_errno($con)." : ".mysqli_error($con));

        #Finalmente deletando informações no banco
        echo "<hr>DELETE FROM {$tabela} WHERE {$identificacao} ;<br>";
		mysqli_query($con,"DELETE FROM {$tabela} WHERE {$identificacao} ; ")or die('<br>Erro na Query do DELETE!<br>'.mysqli_errno($con)." : ".mysqli_error($con));

        #Fechar conexão com o Banco
        mysqli_close($con);
	}

    function alterar($tabela,$coluna,$valor,$identificacao){
        #Abrir conexão
        $con=mysqli_connect( "localhost", "sysadmin", "bhartolomeu1" ) or die( ' Erro na conexão do Método DELETE!<br>'.mysqli_errno($con)." : ".mysqli_error($con));
        mysqli_select_db($con,"insert")or die('Erro na seleção do Banco de Dados do Método DELETE!<br>'.mysqli_errno($con)." : ".mysqli_error($con));

        #Finalmente alterando informações no banco
        echo "<hr>UPDATE {$tabela} SET {$coluna}='{$valor}' WHERE {$identificacao} ; <br>";
		mysqli_query($con,"UPDATE {$tabela} SET {$coluna}='{$valor}' WHERE {$identificacao} ; ")or die('<br>Erro na Query do UPDATE!<br>'.mysqli_errno($con)." : ".mysqli_error($con));
    }
}
?>
