<?php
class Teste{
    public function __construct($nota,$data){

        $this->nota=$nota;
        $this->data=$data;
    }
public function corrigir($list_resp_al,$list_resp_certa){
        $nota=0
        for ($i=0; $i < 8; ++$i){        
            if ($resp_al[$i]==$resp_certa[$i]){
                ++$nota;
            }
        }
        return $nota;
    }
}
$a=[];
$b=[];
$c=[];
$a[0]=['1',$_POST['questao1']];
$a[1]=['2',$_POST['questao2']];
$a[2]=['3',$_POST['questao3']];
$a[3]=['4',$_POST['questao4']];
$a[4]=['5',$_POST['questao5']];
$a[5]=['6',$_POST['questao6']];
$a[6]=['7',$_POST['questao7']];
$a[7]=['8',$_POST['questao8']];

$file=fopen();
while(! feof($file)) {
  $line = fgets($file);
  echo $line. "<br>";
  $b[]=explode(",",$line);
  $c[]=$b;
}
$teste= new Teste(date("Y-m-d"),0);
$teste->nota=$teste->corrigir($a,$c);
echo "Data: {$teste->data}<br>Nota: {$teste->nota}";

?>
