drop database Approva;
CREATE DATABASE Approva;
USE Approva ;
CREATE TABLE IF NOT EXISTS Usuario (
  id_usuario INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(45) NOT NULL,
  email VARCHAR(45) BINARY NOT NULL,
  senha VARCHAR(61) NOT NULL,
  andamento INT NOT NULL DEFAULT '1',
  PRIMARY KEY (id_usuario));  
  
CREATE TABLE IF NOT EXISTS mes (
  id_mes INT NOT NULL AUTO_INCREMENT,
  conteudo VARCHAR(600) NOT NULL,
  PRIMARY KEY (id_mes));

CREATE TABLE IF NOT EXISTS Teste_Mensal (
  id_Teste_Mensal INT NOT NULL AUTO_INCREMENT,
  nota INT NOT NULL,
  data_teste DATE NOT NULL,
  id_mes INT NOT NULL,
  id_usuario INT NOT NULL,
  PRIMARY KEY (id_Teste_Mensal,id_mes,id_usuario),
  FOREIGN KEY (id_mes)REFERENCES mes (id_mes),
  FOREIGN KEY (id_usuario)REFERENCES Usuario (id_usuario));
  
  